-- MySQL dump 10.13  Distrib 5.7.3-m13, for Win64 (x86_64)
--
-- Host: localhost    Database: cms
-- ------------------------------------------------------
-- Server version	5.7.3-m13

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `t_attachment`
--

DROP TABLE IF EXISTS `t_attachment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_attachment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `is_attach` int(11) DEFAULT NULL,
  `is_img` int(11) DEFAULT NULL,
  `is_index_pic` int(11) DEFAULT NULL,
  `new_name` varchar(255) DEFAULT NULL,
  `old_name` varchar(255) DEFAULT NULL,
  `size` bigint(20) NOT NULL,
  `suffix` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `tid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_lalijwufongyebtt0cywu5dm4` (`tid`),
  CONSTRAINT `FK_lalijwufongyebtt0cywu5dm4` FOREIGN KEY (`tid`) REFERENCES `t_topic` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_attachment`
--

LOCK TABLES `t_attachment` WRITE;
/*!40000 ALTER TABLE `t_attachment` DISABLE KEYS */;
INSERT INTO `t_attachment` VALUES (1,0,0,0,'1444116548773.txt','上机报告02_代码',412,'txt','application/octet-stream',1),(2,1,0,0,'1444118455238.doc','上机报告02',123904,'doc','application/octet-stream',3),(3,0,1,0,'1444122807501.jpg','1131907198420455d6o',283723,'jpg','application/octet-stream',3),(4,0,1,0,'1444124998816.jpg','u=19226596,1176876005&fm=21&gp=0',11469,'jpg','application/octet-stream',5),(5,0,1,1,'1444125072670.jpg','1131907198420455d6o',283723,'jpg','application/octet-stream',6),(6,0,1,0,'1444125072818.jpg','u=19226596,1176876005&fm=21&gp=0',11469,'jpg','application/octet-stream',6),(7,0,1,0,'1444125455936.jpg','240451-13050106450911',61461,'jpg','application/octet-stream',7),(8,0,1,0,'1444125456114.jpg','u=19226596,1176876005&fm=21&gp=0',11469,'jpg','application/octet-stream',7);
/*!40000 ALTER TABLE `t_attachment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_channel`
--

DROP TABLE IF EXISTS `t_channel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_channel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `custom_link` int(11) DEFAULT NULL,
  `custom_link_url` varchar(255) DEFAULT NULL,
  `is_index` int(11) DEFAULT NULL,
  `is_top_nav` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `nav_order` int(11) DEFAULT NULL,
  `orders` int(11) NOT NULL,
  `recommend` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `type` int(11) DEFAULT NULL,
  `pid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_8xberajm2i2c97rwrellh0eqk` (`pid`),
  CONSTRAINT `FK_8xberajm2i2c97rwrellh0eqk` FOREIGN KEY (`pid`) REFERENCES `t_channel` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_channel`
--

LOCK TABLES `t_channel` WRITE;
/*!40000 ALTER TABLE `t_channel` DISABLE KEYS */;
INSERT INTO `t_channel` VALUES (39,0,'',0,1,'学校�?��',1,1,0,0,0,NULL),(40,0,'',0,1,'校园之窗',4,2,0,0,0,NULL),(41,0,'',0,1,'教育科研',5,4,0,0,0,NULL),(42,0,'',0,1,'德育园地',7,3,0,0,0,NULL),(43,0,'',1,0,'学校概况',0,3,0,0,2,39),(44,0,'',0,0,'发展动�?',0,4,0,0,1,39),(45,0,'',0,1,'师生风采',8,2,0,0,3,39),(46,0,'',0,1,'校园文化',9,1,0,0,1,39),(47,0,'',1,0,'校园快讯',0,1,0,0,1,40),(48,0,'',1,0,'校务公开',0,2,0,0,1,40),(49,0,'',0,0,'工作指南',0,3,0,0,1,40),(50,0,'',0,1,'党团工作',6,4,0,0,1,40),(51,0,'',0,0,'后勤保障',0,5,0,0,1,40),(52,0,'',1,0,'教科信息',0,1,0,0,1,41),(53,0,'',0,0,'教科成果',0,2,0,0,1,41),(54,0,'',0,0,'校本工作',0,3,0,0,1,41),(55,0,'',0,1,'学科资源',2,4,0,0,1,41),(56,0,'',0,0,'群星闪烁',0,1,0,0,3,42),(57,0,'',1,1,'德育建设',3,2,0,0,1,42),(58,0,'',0,0,'班级工作',0,3,0,0,1,42);
/*!40000 ALTER TABLE `t_channel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_cms_link`
--

DROP TABLE IF EXISTS `t_cms_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_cms_link` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `new_win` int(11) DEFAULT NULL,
  `pos` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `type` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `url_class` varchar(255) DEFAULT NULL,
  `url_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_cms_link`
--

LOCK TABLES `t_cms_link` WRITE;
/*!40000 ALTER TABLE `t_cms_link` DISABLE KEYS */;
INSERT INTO `t_cms_link` VALUES (3,0,2,'百度','lalal','https://www.baidu.com/','fewfw','fefe'),(10,0,3,'fefe','wxh1','fwef','',''),(11,0,1,'wxh1','wxh1','','','');
/*!40000 ALTER TABLE `t_cms_link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_group`
--

DROP TABLE IF EXISTS `t_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descr` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_group`
--

LOCK TABLES `t_group` WRITE;
/*!40000 ALTER TABLE `t_group` DISABLE KEYS */;
INSERT INTO `t_group` VALUES (1,'负责财务部门的网�?,'财务�?),(2,'负责财务部门的网�?,'计科�?),(3,'负责财务部门的网�?,'宣传�?);
/*!40000 ALTER TABLE `t_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_group_channel`
--

DROP TABLE IF EXISTS `t_group_channel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_group_channel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `c_id` int(11) DEFAULT NULL,
  `g_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKB7D322B8D80AB7D1` (`c_id`),
  KEY `FKB7D322B8EF562C89` (`g_id`),
  CONSTRAINT `FKB7D322B8D80AB7D1` FOREIGN KEY (`c_id`) REFERENCES `t_channel` (`id`),
  CONSTRAINT `FKB7D322B8EF562C89` FOREIGN KEY (`g_id`) REFERENCES `t_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_group_channel`
--

LOCK TABLES `t_group_channel` WRITE;
/*!40000 ALTER TABLE `t_group_channel` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_group_channel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_index_pic`
--

DROP TABLE IF EXISTS `t_index_pic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_index_pic` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `create_date` datetime DEFAULT NULL,
  `link_type` int(11) DEFAULT NULL,
  `link_url` varchar(255) DEFAULT NULL,
  `new_name` varchar(255) DEFAULT NULL,
  `old_name` varchar(255) DEFAULT NULL,
  `pos` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `sub_title` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_index_pic`
--

LOCK TABLES `t_index_pic` WRITE;
/*!40000 ALTER TABLE `t_index_pic` DISABLE KEYS */;
INSERT INTO `t_index_pic` VALUES (1,'2015-10-06 15:42:12',0,'','1444117309109.jpg',NULL,5,1,'','dddd'),(2,'2015-10-06 15:42:43',0,'','1444117341653.jpg',NULL,4,1,'fwefw','fefefefefe'),(3,'2015-10-06 15:43:04',0,'','1444117369362.jpg',NULL,3,1,'','ffffff'),(4,'2015-10-06 15:46:23',0,'','1444117576544.jpg',NULL,2,1,'','fefwwe'),(5,'2015-10-06 15:46:43',0,'','1444117595897.jpg',NULL,1,1,'','fwefew');
/*!40000 ALTER TABLE `t_index_pic` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_keyword`
--

DROP TABLE IF EXISTS `t_keyword`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_keyword` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `name_full_py` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `name_short_py` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `times` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_keyword`
--

LOCK TABLES `t_keyword` WRITE;
/*!40000 ALTER TABLE `t_keyword` DISABLE KEYS */;
INSERT INTO `t_keyword` VALUES (1,'ab','ab',NULL,1),(2,'bc','bc',NULL,2),(3,'cd','cd',NULL,3),(4,'ef','ef',NULL,4),(5,'fg','fg',NULL,5),(6,'abc','abc',NULL,6),(7,'bcd','bcd',NULL,7),(8,'efg','efg',NULL,8),(9,'aaa','aaa',NULL,9),(10,'bbb','bbb',NULL,10),(11,'测试lanm','ceshilanm','cs',3),(12,'栏目','lanmu','lm',2),(13,'新生入学','xinshengruxue','xsrx',1),(14,'报到信息','baodaoxinxi','bdxx',2),(15,'导航','daohang','dh',1),(16,'新生报到','xinshengbaodao','xsbd',2),(17,'打击�?,'dajile','djl',3),(18,'尼玛','nima','nm',2),(19,'fefe','fefe','',1),(20,'fef','fef','',1),(21,'少妇','shaofu','sf',1),(22,'个个�?,'gegeren','ggr',3);
/*!40000 ALTER TABLE `t_keyword` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_role`
--

DROP TABLE IF EXISTS `t_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `role_type` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_role`
--

LOCK TABLES `t_role` WRITE;
/*!40000 ALTER TABLE `t_role` DISABLE KEYS */;
INSERT INTO `t_role` VALUES (1,'超级管理�?,'ROLE_ADMIN'),(2,'文章审核人员','ROLE_AUDIT'),(3,'文章发布人员','ROLE_PUBLISH');
/*!40000 ALTER TABLE `t_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_topic`
--

DROP TABLE IF EXISTS `t_topic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_topic` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `author` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `channel_pic_id` int(11) DEFAULT NULL,
  `content` text COLLATE utf8_bin,
  `create_date` datetime DEFAULT NULL,
  `keyword` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `publish_date` datetime DEFAULT NULL,
  `recommend` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `summary` text COLLATE utf8_bin,
  `title` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `cid` int(11) DEFAULT NULL,
  `uid` int(11) DEFAULT NULL,
  `cname` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKA10609A4D7DDC618` (`cid`),
  KEY `FKA10609A452119F24` (`uid`),
  CONSTRAINT `FKA10609A452119F24` FOREIGN KEY (`uid`) REFERENCES `t_user` (`id`),
  CONSTRAINT `FKA10609A4D7DDC618` FOREIGN KEY (`cid`) REFERENCES `t_channel` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_topic`
--

LOCK TABLES `t_topic` WRITE;
/*!40000 ALTER TABLE `t_topic` DISABLE KEYS */;
INSERT INTO `t_topic` VALUES (1,'超级管理�?,0,'<p style=\"padding: 0px; margin: 12px 0px 0.5em; color: rgb(51, 51, 51); font-family: 宋体; font-size: 10.5pt; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; orphans: auto; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-align: justify; line-height: 1.5; text-indent: 2em; background-color: rgb(255, 255, 255);\"><span style=\"padding: 0px; margin: 0px; font-size: 15pt;\">为激发音乐学专业学生的学习热情，提高学生学习的主动�?和积极�?，加强对学生实践能力的培养，师范学院积极实行教学改革，经学院党政联席会议研究决定，自2015�?月份�?��每月举办�?��“音乐学专业月度音乐会�?�?/span></p><p style=\"padding: 0px; margin: 12px 0px 0.5em; color: rgb(51, 51, 51); font-family: 宋体; font-size: 10.5pt; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; orphans: auto; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-align: justify; line-height: 1.5; text-indent: 2em; background-color: rgb(255, 255, 255);\"><span style=\"padding: 0px; margin: 0px; font-size: 15pt;\">9�?4日晚，师范学院在艺术楼演奏厅成功举办了第�?��主题为�?活力音符，秀我所�??的月度音乐会。师范学院相关负责人及全体音乐专业�?师出席了音乐会�?2012级�?2013级和2014级音乐学专业的学生参加了音乐会�?</span></p><p style=\"padding: 0px; margin: 12px 0px 0.5em; color: rgb(51, 51, 51); font-family: 宋体; font-size: 10.5pt; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; orphans: auto; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-align: justify; line-height: 1.5; text-indent: 2em; background-color: rgb(255, 255, 255);\"><span style=\"padding: 0px; margin: 0px; font-size: 15pt;\">在音乐会上，同学们表演了30多个自编自演的节目，节目形式多样，有古筝合奏、钢琴四手联弹�?弦乐重奏、合唱�?器乐合奏、声乐演唱�?大提琴合奏�?吉他弹唱、配乐诗朗诵、舞蹈，等等。每个节目都是同学们在�?师的指导下，自己选择或编排的。整场音乐会的组织策划及现场演出的各个环节均由学生负责完成的。音乐学专业的�?师们为每个节目进行了现场打分，评选出三个“优�?��目奖”，并举行了颁奖仪式。同时，老师们对每个节目进行了点评，指出了优点和不足，提出了改进的意见和建议�?/span></p><p style=\"padding: 0px; margin: 12px 0px 0.5em; color: rgb(51, 51, 51); font-family: 宋体; font-size: 10.5pt; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; orphans: auto; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-align: justify; line-height: 1.5; text-indent: 2em; background-color: rgb(255, 255, 255);\"><span style=\"padding: 0px; margin: 0px; font-size: 15pt;\">通过举办“音乐学专业月度音乐会�?，增加了同学们的学习压力，增添了同学们的学习动力，极大地提高了同学们学习的主动�?和积极�?，提高了同学们的艺术实践能力，在同学中形成了�?��相互竞争的良好学习氛围�?同时，在音乐会上，�?师们的现场点评使同学们深受启发�?获益匪浅。同学们通过自己独立自主地组织整场音乐会，掌握了自主举办整场音乐会的�?��，积累了独立组织举办音乐会的宝贵经验，为今后的就业打下了坚实的基�??</span></p><p style=\"padding: 0px; margin: 12px 0px 0.5em; color: rgb(51, 51, 51); font-family: 宋体; font-size: 10.5pt; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; orphans: auto; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-align: justify; line-height: 1.5; text-indent: 2em; background-color: rgb(255, 255, 255);\"><span style=\"padding: 0px; margin: 0px; font-size: 15pt;\">同学们高兴地说，希望学院今后多举办这样的专业活动�?/span></p>','2015-10-06 15:29:44','fefe|fef|少妇|','2015-10-06 15:29:44',0,1,'','师范学院举办月度音乐�?探索教学改革新模�?,47,3,'校园快讯'),(2,'超级管理�?,0,'','2015-10-06 15:31:05','','2015-10-06 15:31:05',0,1,'学校概况学校概况学校概况学校概况学校概况学校概况学校概况学校概况学校概况学校概况学校概况学校概况学校概况学校概况学校概况学校概况学校概况学校概况学校概况学校概况学校概况学校概况学校概况学校概况学校概况','学校概况',43,3,'学校概况'),(3,'超级管理�?,3,'<a href=\"/cms/resources/upload/1444118455238.doc\" id=\"attach_2\">上机报告02</a>','2015-10-06 16:01:03','','2015-10-06 17:13:41',0,1,'','范围非法�?,57,3,'德育建设'),(4,'超级管理�?,0,'','2015-10-06 16:10:26','','2015-10-06 16:12:42',0,1,'','绯闻绯闻a122',47,3,'校园快讯'),(5,'超级管理�?,4,'feergergerger','2015-10-06 17:46:49','个个人|','2015-10-06 17:50:44',0,1,'','各个如果',45,3,'师生风采'),(6,'超级管理�?,5,'ffffffffffff<img src=\"/cms/resources/upload/1444125072670.jpg\" id=\"attach_5\" alt=\"\" height=\"400\" />','2015-10-06 17:51:31','','2015-10-06 18:01:56',0,1,'','fwfwef111',56,3,'群星闪烁'),(7,'超级管理�?,0,'','2015-10-06 17:57:40','','2015-10-06 17:57:40',0,0,'','fwefwefew',45,3,'师生风采');
/*!40000 ALTER TABLE `t_topic` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_user`
--

DROP TABLE IF EXISTS `t_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `create_date` datetime DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `nickname` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `password` varchar(255) COLLATE utf8_bin NOT NULL,
  `phone` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `status` int(11) NOT NULL,
  `username` varchar(255) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_user`
--

LOCK TABLES `t_user` WRITE;
/*!40000 ALTER TABLE `t_user` DISABLE KEYS */;
INSERT INTO `t_user` VALUES (1,'2010-12-12 00:00:00','admin1@admin.com','管理�?,'123','110',0,'guanly'),(2,'2010-12-12 00:00:00','admin1@admin.com','文章发布人员','123','110',0,'admin2'),(3,'2013-06-03 13:39:13','','超级管理�?,'192023a7bbd73250516f069df18b500','123',1,'admin'),(4,'2015-10-01 16:39:33','274919079@qq.com','ddd','b07c64bb59cf8e608cebfc004c9b78ba','',0,'heheh');
/*!40000 ALTER TABLE `t_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_user_group`
--

DROP TABLE IF EXISTS `t_user_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_user_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `g_id` int(11) DEFAULT NULL,
  `u_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK300645B6EF562C89` (`g_id`),
  KEY `FK300645B652467BF9` (`u_id`),
  CONSTRAINT `FK300645B652467BF9` FOREIGN KEY (`u_id`) REFERENCES `t_user` (`id`),
  CONSTRAINT `FK300645B6EF562C89` FOREIGN KEY (`g_id`) REFERENCES `t_group` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_user_group`
--

LOCK TABLES `t_user_group` WRITE;
/*!40000 ALTER TABLE `t_user_group` DISABLE KEYS */;
INSERT INTO `t_user_group` VALUES (1,3,4);
/*!40000 ALTER TABLE `t_user_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_user_role`
--

DROP TABLE IF EXISTS `t_user_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_user_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `r_id` int(11) DEFAULT NULL,
  `u_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK331DEE5F5243B387` (`r_id`),
  KEY `FK331DEE5F52467BF9` (`u_id`),
  CONSTRAINT `FK331DEE5F5243B387` FOREIGN KEY (`r_id`) REFERENCES `t_role` (`id`),
  CONSTRAINT `FK331DEE5F52467BF9` FOREIGN KEY (`u_id`) REFERENCES `t_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_user_role`
--

LOCK TABLES `t_user_role` WRITE;
/*!40000 ALTER TABLE `t_user_role` DISABLE KEYS */;
INSERT INTO `t_user_role` VALUES (1,1,3),(2,1,4),(3,2,4);
/*!40000 ALTER TABLE `t_user_role` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-10-06 20:18:52
