-- MySQL dump 10.13  Distrib 5.7.3-m13, for Win64 (x86_64)
--
-- Host: localhost    Database: cms
-- ------------------------------------------------------
-- Server version	5.7.3-m13

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `t_attachment`
--

DROP TABLE IF EXISTS `t_attachment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_attachment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `is_attach` int(11) DEFAULT NULL,
  `is_img` int(11) DEFAULT NULL,
  `is_index_pic` int(11) DEFAULT NULL,
  `new_name` varchar(255) DEFAULT NULL,
  `old_name` varchar(255) DEFAULT NULL,
  `size` bigint(20) NOT NULL,
  `suffix` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `tid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_lalijwufongyebtt0cywu5dm4` (`tid`),
  CONSTRAINT `FK_lalijwufongyebtt0cywu5dm4` FOREIGN KEY (`tid`) REFERENCES `t_topic` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_attachment`
--

LOCK TABLES `t_attachment` WRITE;
/*!40000 ALTER TABLE `t_attachment` DISABLE KEYS */;
INSERT INTO `t_attachment` VALUES (1,0,1,0,'1442329002504.jpg','示例图片_01',97609,'jpg','application/octet-stream',1),(2,0,1,0,'1442329002781.jpg','示例图片_02',89100,'jpg','application/octet-stream',1),(22,0,0,0,'1443164373546.doc','2012版软件工程专业人才培养计划V2.0',285184,'doc','application/octet-stream',2),(23,0,0,0,'1443164373587.doc','',158208,'doc','application/octet-stream',2),(29,0,1,0,'1443186485486.png','dede',77569,'png','application/octet-stream',20),(30,0,0,0,'1443186486042.doc','2012版软件工程专业人才培养计划V2.0',285184,'doc','application/octet-stream',20),(40,0,0,0,'1443200880711.doc','2012版软件工程专业人才培养计划V2.0',285184,'doc','application/octet-stream',30),(41,1,0,0,'1443200914241.doc','2012版软件工程专业人才培养计划V2.0',285184,'doc','application/octet-stream',31),(45,0,1,0,'1443202821351.png','dede',77569,'png','application/octet-stream',32),(46,1,0,0,'1443253648840.docx','java招聘',103555,'docx','application/octet-stream',47),(50,0,0,0,'1443254471100.txt','linux',107,'txt','application/octet-stream',48),(53,0,1,0,'1443439989247.png','oracle',13529,'png','application/octet-stream',50);
/*!40000 ALTER TABLE `t_attachment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_channel`
--

DROP TABLE IF EXISTS `t_channel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_channel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `custom_link` int(11) DEFAULT NULL,
  `custom_link_url` varchar(255) DEFAULT NULL,
  `is_index` int(11) DEFAULT NULL,
  `is_top_nav` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `nav_order` int(11) DEFAULT NULL,
  `orders` int(11) NOT NULL,
  `recommend` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `type` int(11) DEFAULT NULL,
  `pid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_8xberajm2i2c97rwrellh0eqk` (`pid`),
  CONSTRAINT `FK_8xberajm2i2c97rwrellh0eqk` FOREIGN KEY (`pid`) REFERENCES `t_channel` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_channel`
--

LOCK TABLES `t_channel` WRITE;
/*!40000 ALTER TABLE `t_channel` DISABLE KEYS */;
INSERT INTO `t_channel` VALUES (1,0,'',0,0,'用户管理模块',0,4,0,0,1,NULL),(2,0,'',0,0,'用户管理1',0,1,0,0,1,1),(3,0,'',0,0,'用户管理2',1,2,0,0,1,1),(4,0,'',0,0,'用户管理3',0,3,0,0,1,1),(5,0,'',0,0,'用户管理4',0,4,0,0,1,1),(6,0,'',0,1,'文章管理模块',0,2,1,1,1,NULL),(7,0,'',0,0,'文章管理1',0,1,0,0,1,6),(8,0,'',0,0,'文章管理2',0,3,0,0,1,6),(9,0,'',0,0,'文章管理3',0,2,0,0,1,6),(10,0,'',0,1,'系统管理模块',0,3,1,1,1,NULL),(11,0,'',0,0,'系统管理1',0,2,0,0,1,10),(12,0,'',0,0,'系统管理2',0,4,0,0,1,10),(13,0,'',0,0,'系统管理3',0,1,0,0,1,10),(14,0,'',0,0,'系统管理4',0,3,0,0,1,10),(15,0,'',0,0,'招生管理模块',0,1,0,0,1,NULL),(16,0,'',0,0,'招生管理1',0,3,0,0,1,15),(17,0,'',0,0,'招生管理2',0,4,0,0,1,15),(18,0,'',0,0,'招生管理3',0,1,0,0,1,15),(19,0,'',0,0,'招生管理4',0,2,0,0,1,15);
/*!40000 ALTER TABLE `t_channel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_cms_link`
--

DROP TABLE IF EXISTS `t_cms_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_cms_link` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `new_win` int(11) DEFAULT NULL,
  `pos` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `type` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `url_class` varchar(255) DEFAULT NULL,
  `url_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_cms_link`
--

LOCK TABLES `t_cms_link` WRITE;
/*!40000 ALTER TABLE `t_cms_link` DISABLE KEYS */;
INSERT INTO `t_cms_link` VALUES (2,1,5,'wefgwef111fr','fwefe','gwegwe','fefe','fef'),(3,0,1,'百度','lalal','https://www.baidu.com/','fewfw','fefe'),(6,0,6,'fwfw','wxh1','fwefw','fwefwe','fwfwfw'),(7,1,2,'efefe','wxh1','fwef','fefe','fwefwe'),(8,0,3,'fwefwe','wxh1','ff','',''),(10,0,4,'fefe','wxh1','fwef','','');
/*!40000 ALTER TABLE `t_cms_link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_group`
--

DROP TABLE IF EXISTS `t_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descr` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_group`
--

LOCK TABLES `t_group` WRITE;
/*!40000 ALTER TABLE `t_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_group_channel`
--

DROP TABLE IF EXISTS `t_group_channel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_group_channel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `c_id` int(11) DEFAULT NULL,
  `g_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_24eett7giwwdgdjmras9awwyg` (`c_id`),
  KEY `FK_t99wvp6hj7fgi3oexkb4ogeyp` (`g_id`),
  CONSTRAINT `FK_24eett7giwwdgdjmras9awwyg` FOREIGN KEY (`c_id`) REFERENCES `t_channel` (`id`),
  CONSTRAINT `FK_t99wvp6hj7fgi3oexkb4ogeyp` FOREIGN KEY (`g_id`) REFERENCES `t_group` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=86 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_group_channel`
--

LOCK TABLES `t_group_channel` WRITE;
/*!40000 ALTER TABLE `t_group_channel` DISABLE KEYS */;
INSERT INTO `t_group_channel` VALUES (7,15,1),(10,10,1),(15,17,1),(17,6,1),(18,8,1),(19,9,1),(20,7,1),(21,6,3),(22,7,3),(23,8,3),(24,9,3),(25,16,3),(26,15,3),(27,18,3),(28,17,3),(29,19,3),(32,1,1),(33,2,1),(66,18,1),(67,1,2),(68,2,2),(69,4,2),(70,3,2),(71,5,2),(72,6,2),(73,8,2),(74,7,2),(75,9,2),(76,12,1),(78,3,1),(79,4,1),(85,16,1);
/*!40000 ALTER TABLE `t_group_channel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_index_pic`
--

DROP TABLE IF EXISTS `t_index_pic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_index_pic` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `create_date` datetime DEFAULT NULL,
  `link_type` int(11) DEFAULT NULL,
  `link_url` varchar(255) DEFAULT NULL,
  `new_name` varchar(255) DEFAULT NULL,
  `old_name` varchar(255) DEFAULT NULL,
  `pos` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `sub_title` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_index_pic`
--

LOCK TABLES `t_index_pic` WRITE;
/*!40000 ALTER TABLE `t_index_pic` DISABLE KEYS */;
INSERT INTO `t_index_pic` VALUES (1,'2015-09-15 23:21:30',0,'','1442330469130.png',NULL,3,1,'ferfre','fwefweff'),(5,'2015-09-28 19:37:23',1,'','1443440230912.jpg',NULL,2,1,'hhhhhhhh','5555'),(7,'2015-09-28 19:52:03',0,'','1443441108928.png',NULL,1,1,'fwefwe','fwefwe');
/*!40000 ALTER TABLE `t_index_pic` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_keyword`
--

DROP TABLE IF EXISTS `t_keyword`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_keyword` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `name_full_py` varchar(255) DEFAULT NULL,
  `name_short_py` varchar(255) DEFAULT NULL,
  `times` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_keyword`
--

LOCK TABLES `t_keyword` WRITE;
/*!40000 ALTER TABLE `t_keyword` DISABLE KEYS */;
INSERT INTO `t_keyword` VALUES (1,'我是吴晓�?,'woshiwuxiaohao','wswxh',2),(2,'fwef','fwef','',2),(3,'fewfew','fewfew','',2),(4,'fwefwe','fwefwe','',1),(5,'fwefw','fwefw','',1),(6,'fwefew','fwefew','',2),(7,'非法','feifa','',1),(8,'fefe','fefe','',7),(9,'fff','fff','',1),(10,'fefefe','fefefe','',1),(11,'fwfw','fwfw','',1);
/*!40000 ALTER TABLE `t_keyword` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_role`
--

DROP TABLE IF EXISTS `t_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `role_type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_role`
--

LOCK TABLES `t_role` WRITE;
/*!40000 ALTER TABLE `t_role` DISABLE KEYS */;
INSERT INTO `t_role` VALUES (1,'超级管理�?,'ROLE_ADMIN'),(9,'ewfwefweA','ROLE_ADMIN'),(21,'dedefwfwe','ROLE_ADMIN'),(22,'fefe','ROLE_ADMIN'),(23,'dee','ROLE_ADMIN'),(24,'fefe','ROLE_ADMIN');
/*!40000 ALTER TABLE `t_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_topic`
--

DROP TABLE IF EXISTS `t_topic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_topic` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `author` varchar(255) DEFAULT NULL,
  `channel_pic_id` int(11) DEFAULT NULL,
  `cname` varchar(255) DEFAULT NULL,
  `content` longtext,
  `create_date` datetime DEFAULT NULL,
  `keyword` varchar(255) DEFAULT NULL,
  `publish_date` datetime DEFAULT NULL,
  `recommend` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `summary` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `cid` int(11) DEFAULT NULL,
  `uid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_59g28og282jx0yiqcrk8kayre` (`cid`),
  KEY `FK_m3hlahy6pc6ywlp3601me865s` (`uid`),
  CONSTRAINT `FK_59g28og282jx0yiqcrk8kayre` FOREIGN KEY (`cid`) REFERENCES `t_channel` (`id`),
  CONSTRAINT `FK_m3hlahy6pc6ywlp3601me865s` FOREIGN KEY (`uid`) REFERENCES `t_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_topic`
--

LOCK TABLES `t_topic` WRITE;
/*!40000 ALTER TABLE `t_topic` DISABLE KEYS */;
INSERT INTO `t_topic` VALUES (1,'admin',0,'文章管理3','<img src=\"/cms/resources/upload/1442329002781.jpg\" id=\"attach_2\" alt=\"\" height=\"400\" />','2015-09-15 22:56:47','我是吴晓豪|','2015-09-15 22:57:09',0,1,'','fwefwe',9,1),(2,'admin',0,'招生管理2','fwefnlwenfjkwenfkjwenjfwejkfjkwe','2015-09-25 14:59:56','fwef|','2015-09-25 14:59:56',0,1,'','fwefwefwe',17,1),(5,'admin',0,'招生管理2','','2015-09-25 15:44:56','','2015-09-25 15:44:56',0,1,'','fwefwe',17,1),(6,'admin',0,'招生管理1','','2015-09-25 15:45:47','','2015-09-25 15:45:47',0,1,'','fwefwefew',16,1),(12,'admin',0,'招生管理1','','2015-09-25 16:45:09','','2015-09-25 16:45:09',0,0,'','fwefwefew',16,1),(13,'admin',0,'用户管理1','','2015-09-25 16:46:39','','2015-09-25 16:46:39',0,1,'','defwe',2,1),(14,'admin',0,'招生管理1','','2015-09-25 16:47:08','','2015-09-25 16:47:08',0,0,'','我终于测试成功了�?,16,1),(16,'admin',0,'招生管理2','','2015-09-25 17:00:24','','2015-09-25 17:00:24',0,0,'','蜂窝�?,17,1),(19,'admin',0,'招生管理1','','2015-09-25 17:15:40','fewfew|','2015-09-25 17:15:40',0,1,'','wuxiaohao',16,1),(20,'admin',0,'招生管理2','ffffffffffffffffffffff<img src=\"/cms/resources/upload/1443186485486.png\" id=\"attach_29\" height=\"400\" alt=\"\" />','2015-09-25 21:08:13','fwefew|','2015-09-25 21:08:13',0,0,'','fwefwe',17,1),(21,'admin',0,'招生管理1','fwfwefwe<img alt=\"大笑\" src=\"/cms/resources/xheditor/xheditor_emot/default/laugh.gif\" />','2015-09-25 21:33:58','','2015-09-25 01:36:28',0,0,'','测试文章显示是否成功了！！！',16,1),(24,'adminwxh',0,'招生管理4','','2015-09-25 22:52:52','fefe|','2015-09-25 22:52:52',0,0,'','fwfwe',19,1),(27,'adminwxh',0,'招生管理4','','2015-09-25 23:23:27','','2015-09-25 23:23:27',0,0,'','fwefweeee',19,1),(30,'adminwxh',0,'招生管理1','','2015-09-26 01:08:11','','2015-09-26 01:08:11',0,0,'','�?,16,1),(31,'adminwxh',0,'招生管理4','','2015-09-26 01:08:43','fefefe|fefe|','2015-09-26 01:39:40',1,1,'','�?,19,1),(32,'adminwxh',0,'招生管理3','<img alt=\"大哭\" src=\"/cms/resources/xheditor/xheditor_emot/default/wail.gif\" />','2015-09-26 01:40:58','fefe|','2015-09-26 01:44:47',1,1,'终于搞完了尼玛！！！！！','终于搞完了尼玛！！！！！？？�?,18,1),(33,'adminwxh',0,'招生管理4','','2015-09-26 11:04:02','','2015-09-26 11:04:02',1,1,'','wxh4444',19,1),(34,'adminwxh',0,'招生管理2','','2015-09-26 11:04:30','','2015-09-26 11:04:30',1,0,'','wuxiaohap',17,1),(35,'adminwxh',0,'招生管理4','','2015-09-26 11:05:56','','2015-09-26 11:05:56',1,1,'','hehe',19,1),(36,'adminwxh',0,'招生管理1','','2015-09-26 11:06:45','','2015-09-26 18:57:45',0,1,'','dddaaaa',16,1),(37,'adminwxh',0,'招生管理4','','2015-09-26 11:08:09','','2015-09-26 18:54:06',0,1,'','1234567812345678888',19,1),(38,'adminwxh',0,'招生管理1','','2015-09-26 13:29:04','','2015-09-26 13:29:04',0,0,'','111',16,1),(39,'adminwxh',0,'招生管理4','','2015-09-26 13:29:17','','2015-09-26 13:29:17',0,0,'','222',19,1),(42,'adminwxh',0,'招生管理4','','2015-09-26 15:10:51','','2015-09-26 15:10:51',0,0,'','fefe',19,1),(43,'adminwxh',0,'招生管理4','','2015-09-26 15:11:24','','2015-09-26 15:11:24',1,0,'','wfwewe',19,1),(44,'adminwxh',0,'招生管理4','','2015-09-26 15:12:06','','2015-09-26 15:12:06',0,0,'','fwefwe',19,1),(47,'adminwxh',0,'招生管理3','<a href=\"/cms/resources/upload/1443253648840.docx\" id=\"attach_46\">java招聘</a>','2015-09-26 15:47:45','','2015-09-26 18:57:29',0,1,'','heh12222',18,1),(48,'adminwxh',0,'招生管理4','','2015-09-26 16:01:16','fwfw|fwef|','2015-09-26 16:01:16',0,0,'','fwefwe',19,1),(50,'adminwxh',0,'招生管理4','','2015-09-28 19:33:15','','2015-09-28 19:33:15',1,1,'','wxh66666',19,1),(51,'adminwxh',0,'招生管理4','','2015-09-28 19:37:43','','2015-09-28 19:37:43',0,0,'','23232',19,1),(52,'adminwxh',0,'招生管理4','','2015-09-28 19:37:59','','2015-09-28 19:37:59',0,1,'','ewrwe',19,1),(53,'adminwxh',0,'系统管理4','','2015-09-28 19:39:33','','2015-09-28 19:39:33',0,1,'','123',14,1),(54,'adminwxh',0,'招生管理4','','2015-09-28 19:42:26','','2015-09-28 19:42:26',0,1,'','123222',19,1),(55,'adminwxh',0,'招生管理2','','2015-09-28 19:46:17','','2015-09-28 19:46:17',0,1,'','efefe',17,1),(56,'adminwxh',0,'招生管理2','','2015-09-28 19:52:37','','2015-09-28 19:52:37',0,0,'','在不成功我吃�?,17,1),(57,'adminwxh',0,'招生管理4','','2015-09-28 20:46:26','','2015-09-28 20:46:26',0,0,'','......',19,1),(58,'adminwxh',0,'招生管理1','','2015-09-28 20:46:38','','2015-09-28 20:46:38',0,1,'','l.l.l.l',16,1);
/*!40000 ALTER TABLE `t_topic` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_user`
--

DROP TABLE IF EXISTS `t_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `create_date` datetime DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `nickname` varchar(255) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `status` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_user`
--

LOCK TABLES `t_user` WRITE;
/*!40000 ALTER TABLE `t_user` DISABLE KEYS */;
INSERT INTO `t_user` VALUES (1,'2015-10-03 13:39:13','27419@qq.com','adminwxh','192023a7bbd73250516f069df18b500','15812222334',1,'admin'),(20,'2015-09-21 22:45:12','274919079@qq.com','fwefwef','6c61dab8714a0a1d9a9d27edcbbc437','',0,'wefwefwe'),(21,'2015-09-22 08:48:55','274919079@qq.com','deddaaaa','b80f4edcdf8efcc937507627e6ebd152','',0,'addd'),(22,'2015-09-22 13:15:08','274919079@qq.com','ddd','1a0c73b57a1bd2dd37e6e147d1dc9520','',0,'dew'),(23,'2015-09-26 11:24:32','274919079@qq.com','admin2','7bde05b5fdaa4919faebdf3b110cc904','',0,'admin2');
/*!40000 ALTER TABLE `t_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_user_group`
--

DROP TABLE IF EXISTS `t_user_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_user_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `g_id` int(11) DEFAULT NULL,
  `u_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_q36nttf8633cf61sjj7sk215m` (`g_id`),
  KEY `FK_fpvv55wrj5hjvujeq1sichxx7` (`u_id`),
  CONSTRAINT `FK_fpvv55wrj5hjvujeq1sichxx7` FOREIGN KEY (`u_id`) REFERENCES `t_user` (`id`),
  CONSTRAINT `FK_q36nttf8633cf61sjj7sk215m` FOREIGN KEY (`g_id`) REFERENCES `t_group` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_user_group`
--

LOCK TABLES `t_user_group` WRITE;
/*!40000 ALTER TABLE `t_user_group` DISABLE KEYS */;
INSERT INTO `t_user_group` VALUES (6,1,1),(7,2,1),(8,3,1),(9,1,22),(10,3,22),(11,2,21),(12,1,21),(13,2,20),(14,1,20);
/*!40000 ALTER TABLE `t_user_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_user_role`
--

DROP TABLE IF EXISTS `t_user_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_user_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `r_id` int(11) DEFAULT NULL,
  `u_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_4ncarre027svsmpjoq8eexrgj` (`r_id`),
  KEY `FK_3fofkg6qftsisdskrt3bor23w` (`u_id`),
  CONSTRAINT `FK_3fofkg6qftsisdskrt3bor23w` FOREIGN KEY (`u_id`) REFERENCES `t_user` (`id`),
  CONSTRAINT `FK_4ncarre027svsmpjoq8eexrgj` FOREIGN KEY (`r_id`) REFERENCES `t_role` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_user_role`
--

LOCK TABLES `t_user_role` WRITE;
/*!40000 ALTER TABLE `t_user_role` DISABLE KEYS */;
INSERT INTO `t_user_role` VALUES (1,1,1),(2,1,22),(3,9,22),(4,9,21),(5,1,21),(6,1,23);
/*!40000 ALTER TABLE `t_user_role` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-09-29 21:25:17
